import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.UUID;

public class BicycleRentalSystem {
    private ArrayList<User> users;
    private ArrayList<Bicycle> bicycles;
    private ArrayList<Location> locations;

    public BicycleRentalSystem() {
        users = new ArrayList<>();
        bicycles = new ArrayList<>();
        locations = new ArrayList<>();
        loadData();
    }

    private void loadData() {
        try {
            Scanner userScanner = new Scanner(new File("users.txt"));
            while (userScanner.hasNextLine()) {
                String line = userScanner.nextLine();
                String[] data = line.split(",");
                if (data.length == 3) {
                    users.add(new User(data[0], data[1], data[2]));
                } else {
                    System.out.println("Invalid user data format: " + line);
                }
            }
            userScanner.close();

            Scanner bicycleScanner = new Scanner(new File("bicycles.txt"));
            while (bicycleScanner.hasNextLine()) {
                String line = bicycleScanner.nextLine();
                String[] data = line.split(",");
                if (data.length == 5) {
                    bicycles.add(new Bicycle(data[0], data[1], Double.parseDouble(data[2]), Boolean.parseBoolean(data[3]), Integer.parseInt(data[4])));
                } else {
                    System.out.println("Invalid bicycle data format: " + line);
                }
            }
            bicycleScanner.close();

            Scanner locationScanner = new Scanner(new File("locations.txt"));
            while (locationScanner.hasNextLine()) {
                String line = locationScanner.nextLine();
                String[] data = line.split(",");
                if (data.length == 3) {
                    locations.add(new Location(data[0], Double.parseDouble(data[1]), Double.parseDouble(data[2])));
                } else {
                    System.out.println("Invalid location data format: " + line);
                }
            }
            locationScanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("Error: File not found.");
        }
    }

    public void start() {
        int choice;
        Scanner scanner = new Scanner(System.in);
        do {
            System.out.println("\n===== Bicycle Rental System ======");
            System.out.println("1. Login");
            System.out.println("2. Register");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    login();
                    break;
                case 2:
                    register();
                    break;
                case 3:
                    System.out.println("Thank you for using the Bicycle Rental System!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        } while (choice != 3);
    }

    private void login() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your username: ");
        String username = scanner.nextLine();
        System.out.print("Enter your password: ");
        String password = scanner.nextLine();

        User user = findUser(username, password);
        if (user != null) {
            System.out.println("\nWelcome, " + user.getName() + "!");
            startRental(user);
        } else {
            System.out.println("Invalid username or password.");
        }
    }

    private void register() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your username: ");
        String username = scanner.nextLine();
        System.out.print("Enter your password: ");
        String password = scanner.nextLine();
        System.out.print("Enter your name: ");
        String name = scanner.nextLine();

        User newUser = new User(username, password, name);
        users.add(newUser);
        saveData();

        System.out.println("\nRegistration successful! Your username is " + username + ".");
    }

    private void startRental(User user) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your current location: ");
        String currentLocation = scanner.nextLine();

        ArrayList<Location> nearbyLocations = findNearbyLocations(currentLocation);

        System.out.println("\nNearby Pickup Points:");
        for (Location location : nearbyLocations) {
            System.out.println((nearbyLocations.indexOf(location) + 1) + ". " + location);
        }

        System.out.print("\nSelect a pickup point (enter the number): ");
        int pickupPointIndex = scanner.nextInt() - 1;
        Location pickupPoint = nearbyLocations.get(pickupPointIndex);

        System.out.println("\nSelect a bike category:");
        System.out.println("1. Regular");
        System.out.println("2. Electric");
        System.out.print("Enter your choice: ");
        int categoryChoice = scanner.nextInt();

        ArrayList<Bicycle> availableBikes = findAvailableBikes(categoryChoice);

        System.out.println("\nAvailable Bikes:");
        for (Bicycle bicycle : availableBikes) {
            System.out.println((availableBikes.indexOf(bicycle) + 1) + ". " + bicycle);
        }

        System.out.print("\nEnter the bike code (enter the number): ");
        int bikeCode = scanner.nextInt();
        Bicycle selectedBike = availableBikes.get(bikeCode - 1);

        System.out.print("Enter your dropoff location: ");
        scanner.nextLine();
        String dropoffLocation = scanner.nextLine();

        System.out.print("Enter the rental duration (hours): ");
        int rentalDuration = scanner.nextInt();

        double bill = calculateBill(selectedBike, rentalDuration);

        System.out.printf("\nTotal Bill: TK%.2f\n", bill);

        System.out.print("Confirm rental (Y/N): ");
        scanner.nextLine();
        String confirm = scanner.nextLine();

        if (confirm.equalsIgnoreCase("Y")) {
            System.out.println("\nPayment Methods:");
            System.out.println("1. Bkash");
            System.out.println("2. Card");
            System.out.println("3. Nagad");
            System.out.print("Enter your choice: ");
            int paymentMethod = scanner.nextInt();

            System.out.println("\nBike rented successfully!");
        } else {
            System.out.println("Rental canceled.");
        }
    }

    private ArrayList<Location> findNearbyLocations(String currentLocation) {
        ArrayList<Location> nearbyLocations = new ArrayList<>();

        for (Location location : locations) {
            double distance = calculateDistance(currentLocation, location.getAddress());
            if (distance <= 1) {
                nearbyLocations.add(location);
            }
        }

        return nearbyLocations;
    }

    private ArrayList<Bicycle> findAvailableBikes(int categoryChoice) {
        ArrayList<Bicycle> availableBikes = new ArrayList<>();

        for (Bicycle bicycle : bicycles) {
            if (bicycle.isAvailable() && bicycle.getCategory() == categoryChoice) {
                availableBikes.add(bicycle);
            }
        }

        return availableBikes;
    }

    private double calculateDistance(String location1, String location2) {
        return 0.0;
    }

    private double calculateBill(Bicycle selectedBike, int rentalDuration) {
        double distanceRate = 10;
        double hourRate = 10;

        double totalDistance = 3;

        return totalDistance * distanceRate + rentalDuration * hourRate;
    }

    private User findUser(String username, String password) {
        for (User user : users) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                return user;
            }
        }
        return null;
    }

    private void saveData() {
        try {
            File userFile = new File("users.txt");
            File bicycleFile = new File("bicycles.txt");
            File locationFile = new File("locations.txt");

            userFile.createNewFile();
            bicycleFile.createNewFile();
            locationFile.createNewFile();

            for (User user : users) {
                user.saveToFile(userFile);
            }

            for (Bicycle bicycle : bicycles) {
                bicycle.saveToFile(bicycleFile);
            }

            for (Location location : locations) {
                location.saveToFile(locationFile);
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        BicycleRentalSystem rentalSystem = new BicycleRentalSystem();
        rentalSystem.start();
    }
}

class User {
    private String username;
    private String password;
    private String name;

    public User(String username, String password, String name) {
        this.username = username;
        this.password = password;
        this.name = name;
    }

    public void saveToFile(File file) throws Exception {
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getName() {
        return name;
    }
}

class Bicycle {
    private UUID id;
    private String brand;
    private double basePricePerHour;
    private boolean isAvailable;
    private int category;

    public Bicycle(String id, String brand, double basePricePerHour, boolean isAvailable, int category) {
        this.id = UUID.fromString(id);
        this.brand = brand;
        this.basePricePerHour = basePricePerHour;
        this.isAvailable = isAvailable;
        this.category = category;
    }

    public void saveToFile(File file) throws Exception {
    }

    public UUID getId() {
        return id;
    }

    public String getBrand() {
        return brand;
    }

    public double getBasePricePerHour() {
        return basePricePerHour;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public int getCategory() {
        return category;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Brand: " + brand;
    }
}

class Location {
    private String address;
    private double latitude;
    private double longitude;

    public Location(String address, double latitude, double longitude) {
        this.address = address;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public void saveToFile(File file) throws Exception {
    }

    public String getAddress() {
        return address;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    @Override
    public String toString() {
        return address;
    }
}
