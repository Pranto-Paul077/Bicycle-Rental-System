import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class BicycleRentalSystem extends Application {
    private ArrayList<User> users;
    private ArrayList<Bicycle> bicycles;
    private ArrayList<Location> locations;
    private Stage primaryStage;

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        users = new ArrayList<>();
        bicycles = new ArrayList<>();
        locations = new ArrayList<>();
        loadData();

        primaryStage.setTitle("Bicycle Rental System");
        primaryStage.setScene(createLoginScene());
        primaryStage.show();
    }

    private Scene createLoginScene() {
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setVgap(10);
        grid.setHgap(10);

        Label titleLabel = new Label("Login");
        titleLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");
        GridPane.setConstraints(titleLabel, 0, 0, 2, 1);

        Label usernameLabel = new Label("Username:");
        GridPane.setConstraints(usernameLabel, 0, 1);

        TextField usernameField = new TextField();
        GridPane.setConstraints(usernameField, 1, 1);

        Label passwordLabel = new Label("Password:");
        GridPane.setConstraints(passwordLabel, 0, 2);

        PasswordField passwordField = new PasswordField();
        GridPane.setConstraints(passwordField, 1, 2);

        Button loginButton = new Button("Login");
        loginButton.setOnAction(e -> {
            String username = usernameField.getText();
            String password = passwordField.getText();
            User user = findUser(username, password);
            if (user != null) {
                primaryStage.setScene(createRentalScene(user));
            } else {
                showAlert(Alert.AlertType.ERROR, "Invalid Credentials", "Invalid username or password.");
            }
        });
        GridPane.setConstraints(loginButton, 1, 3);

        grid.getChildren().addAll(titleLabel, usernameLabel, usernameField, passwordLabel, passwordField, loginButton);
        return new Scene(grid, 400, 250);
    }

    private Scene createRentalScene(User user) {
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setVgap(10);
        grid.setHgap(10);

        Label titleLabel = new Label("Bicycle Rental System - Welcome, " + user.getName() + "!");
        titleLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");
        GridPane.setConstraints(titleLabel, 0, 0, 2, 1);

        Label locationLabel = new Label("Enter your current location:");
        GridPane.setConstraints(locationLabel, 0, 1);

        TextField locationField = new TextField();
        GridPane.setConstraints(locationField, 1, 1);

        Button findPickupButton = new Button("Find Pickup Points");
        findPickupButton.setOnAction(e -> {
            String currentLocation = locationField.getText();
            ArrayList<Location> nearbyLocations = findNearbyLocations(currentLocation);

            // Show nearby pickup points in a new scene or dialog
            System.out.println("Nearby Pickup Points:");
            for (Location location : nearbyLocations) {
                System.out.println(location);
            }
        });
        GridPane.setConstraints(findPickupButton, 1, 2);

        // Other rental functionalities like selecting bike, drop-off location, duration, payment, etc.

        grid.getChildren().addAll(titleLabel, locationLabel, locationField, findPickupButton);
        return new Scene(grid, 400, 250);
    }

    private ArrayList<Location> findNearbyLocations(String currentLocation) {
        ArrayList<Location> nearbyLocations = new ArrayList<>();

        for (Location location : locations) {
         }

        return nearbyLocations;
    }

    private void loadData() {
        try {
            Scanner userScanner = new Scanner(new File("users.txt"));
            while (userScanner.hasNextLine()) {
                String line = userScanner.nextLine();
                String[] data = line.split(",");
                if (data.length == 3) {
                    users.add(new User(data[0], data[1], data[2]));
                } else {
                    System.out.println("Invalid user data format: " + line);
                }
            }
            userScanner.close();

            // Similar loading for bicycles and locations
        } catch (FileNotFoundException e) {
            System.out.println("Error: File not found.");
        }
    }

    private User findUser(String username, String password) {
        for (User user : users) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                return user;
            }
        }
        return null;
    }

    private void showAlert(Alert.AlertType alertType, String title, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }

    static class User {
        private String username;
        private String password;
        private String name;

        public User(String username, String password, String name) {
            this.username = username;
            this.password = password;
            this.name = name;
        }

        public String getUsername() {
            return username;
        }

        public String getPassword() {
            return password;
        }

        public String getName() {
            return name;
        }
    }

    static class Bicycle {
        private UUID id;
        private String brand;
        private double basePricePerHour;
        private boolean isAvailable;
        private int category; // 1 for regular, 2 for electric

        public Bicycle(String id, String brand, double basePricePerHour, boolean isAvailable, int category) {
            this.id = UUID.fromString(id);
            this.brand = brand;
            this.basePricePerHour = basePricePerHour;
            this.isAvailable = isAvailable;
            this.category = category;
        }

        public void saveToFile(File file) throws Exception {
            // Implement a method to save the bicycle data to a file
        }

        public UUID getId() {
            return id;
        }

        public String getBrand() {
            return brand;
        }

        public double getBasePricePerHour() {
            return basePricePerHour;
        }

        public boolean isAvailable() {
            return isAvailable;
        }

        public int getCategory() {
            return category;
        }

        @Override
        public String toString() {
            return "ID: " + id + ", Brand: " + brand;
        }
    }

        static class Location {
            private String address;
            private double latitude;
            private double longitude;

            public Location(String address, double latitude, double longitude) {
                this.address = address;
                this.latitude = latitude;
                this.longitude = longitude;
            }

            public void saveToFile(File file) throws Exception {
                // Implement a method to save the location data to a file
            }

            public String getAddress() {
                return address;
            }

            public double getLatitude() {
                return latitude;
            }

            public double getLongitude() {
                return longitude;
            }

            @Override
            public String toString() {
                return address;
            }
            }
}
